var Events = {
    //添加管理员信息弹框
    ShowBox:function(){
        $(".add_alert").show();$(".mark").show();
    },
//关闭弹框
    CloseBox:function(){
        $(".add_alert").hide();$(".mark").hide();
    }
}