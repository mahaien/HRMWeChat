/**
 * Created by Administrator on 2019/3/27.
 */
var Events = {
    //添加用户组信息弹框
    ShowBox:function(){
        $(".add_alert").show();$(".mark").show();
    },
//关闭弹框
    CloseBox:function(){
        $(".add_alert").hide();$(".mark").hide();
    }
}