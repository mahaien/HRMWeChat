/**
 * Created by Administrator on 2019/3/26.
 */
$(function(){
    $("#footer").append(Footer);
});
//底部
var Footer = '<a id="FootNav1" href="Index.html"><i class="iconfont icon-shouye2" style="font-size: 28px;display: block;"></i><p>首页</p></a>'+
    '<a id="FootNav2" href="javascript:void(0);"><i class="iconfont icon-weibiaoti-"style="font-size: 23px;display: block;"></i><p>统计</p></a>'+
    '<a id="FootNav3" href="javascript:void(0);"><i class="iconfont icon-wenhao" style="font-size: 25px;display: block;"></i><p>帮助</p></a>'+
    '<a id="FootNav4" href="AcctSet.html"><i class="iconfont icon-gerenzhongxin"style="font-size: 28px;display: block;"></i><p>账户设置</p></a>'