$(function(){
    $("#FootNav4").addClass("on");
});
