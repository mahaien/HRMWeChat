$(function(){
    $("#FootNav1").addClass("on");
});
